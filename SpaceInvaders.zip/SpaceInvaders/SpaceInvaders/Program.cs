﻿
using var game = new SpaceInvaders.Game1();
game.Run();
